package ke.co.myfuture.Myfuture.Treasury.Transaction.TranValidators;

import ke.co.myfuture.Myfuture.Treasury.Account.Account;
import ke.co.myfuture.Myfuture.Treasury.Account.AccountOwnershipType;
import ke.co.myfuture.Myfuture.Treasury.Account.AccountRepository;
import ke.co.myfuture.Myfuture.Treasury.Transaction.TranEntry.TranEntry;
import ke.co.myfuture.Myfuture.Treasury.Transaction.TranEntry.TranType;
import ke.co.myfuture.Myfuture.Treasury.Transaction.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class IncomeValidator {
    @Autowired
    AccountRepository accountRepository;
    @Autowired
    ValidatorCommons validatorCommons;

    public boolean attachOtherTranEntries(Transaction transaction) {
        Double totalAmount = 0.0;
        for (TranEntry tranEntry: transaction.getTranEntries()) {
            if (tranEntry.getTranType() != TranType.CREDIT || tranEntry.getAmount() <=0 ) {
                return false;
            }
            totalAmount += tranEntry.getAmount();
            Optional<Account> account = accountRepository.findById(tranEntry.getAccountId());
            if (account.isEmpty())
                return false;
            if (account.get().getOwnershipType() != AccountOwnershipType.INCOME) {
                System.out.println("Must be an expense account");
                return false;
            }
            tranEntry.setAccount(account.get());
        }
        return validatorCommons.addCashAccount(totalAmount, TranType.DEBIT, transaction, transaction.getContributionsPlan().getName()+" income ");
    }
}
