package ke.co.myfuture.Myfuture.Tuabudu.Song;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SongService {

}
